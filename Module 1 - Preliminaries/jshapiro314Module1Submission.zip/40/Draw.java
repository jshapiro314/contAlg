public class Draw{

	public static void main (String[] args){

		Function myFunction = new Function("TEST");
		// myFunction.add(8.33, 1666.67);
		// myFunction.add(22.22, 3666.67);
		// myFunction.add(23.61, 4833.33);
		// myFunction.add(30.55, 5000);
		// myFunction.add(36.81, 5166.67);
		// myFunction.add(47.22, 8000);
		// myFunction.add(69.44, 11333.33);
		// myFunction.add(105.56, 19666.67);

		myFunction.add(1,1);
		myFunction.add(2,13);
		myFunction.add(3,33);
		myFunction.add(4,61);
		myFunction.add(5,97);

		myFunction.show();

	}


}